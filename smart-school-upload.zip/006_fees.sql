-- Migration 006: fee structure, invoices, payments (cash / bank transfer / POS), receipts.
-- Run AFTER 001-005. Online card payments are NOT included yet.

create or replace function public.is_finance(p_school uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select public.is_super_admin() or public.is_school_manager(p_school)
         or public.has_school_role(p_school, array['bursar']::public.app_role[]);
$$;

create table if not exists public.fee_items (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null references public.schools(id) on delete cascade,
  session_id uuid not null references public.academic_sessions(id) on delete cascade,
  term_id uuid not null references public.terms(id) on delete cascade,
  class_id uuid not null references public.classes(id) on delete cascade,
  name text not null check (char_length(name) between 2 and 80),
  amount numeric(12,2) not null check (amount > 0),
  created_at timestamptz not null default now(),
  unique (term_id, class_id, name)
);

create table if not exists public.invoices (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null references public.schools(id) on delete cascade,
  student_id uuid not null references public.students(id) on delete cascade,
  class_id uuid references public.classes(id) on delete set null,
  session_id uuid not null references public.academic_sessions(id) on delete cascade,
  term_id uuid not null references public.terms(id) on delete cascade,
  invoice_no text not null,
  gross numeric(12,2) not null default 0,
  discount numeric(12,2) not null default 0 check (discount >= 0),
  discount_reason text,
  net numeric(12,2) generated always as (gross - discount) stored,
  created_by uuid,
  created_at timestamptz not null default now(),
  unique (student_id, term_id),
  unique (school_id, invoice_no),
  check (discount <= gross)
);
create index if not exists idx_invoices_term on public.invoices(school_id, term_id);

create table if not exists public.invoice_items (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null references public.schools(id) on delete cascade,
  invoice_id uuid not null references public.invoices(id) on delete cascade,
  name text not null,
  amount numeric(12,2) not null check (amount > 0)
);
create index if not exists idx_invitems_invoice on public.invoice_items(invoice_id);

create table if not exists public.payments (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null references public.schools(id) on delete cascade,
  invoice_id uuid not null references public.invoices(id) on delete restrict,
  student_id uuid not null references public.students(id) on delete restrict,
  amount numeric(12,2) not null check (amount > 0),
  method text not null check (method in ('cash','bank_transfer','pos','other')),
  reference text,
  paid_on date not null default public.lagos_today(),
  receipt_no text not null,
  received_by uuid,
  note text,
  voided boolean not null default false,
  void_reason text,
  voided_by uuid,
  voided_at timestamptz,
  created_at timestamptz not null default now(),
  unique (school_id, receipt_no),
  check (method in ('cash','other') or nullif(trim(reference), '') is not null)
);
create index if not exists idx_pay_invoice on public.payments(invoice_id);
create index if not exists idx_pay_student on public.payments(student_id);
-- the same transfer/POS reference cannot be recorded twice
create unique index if not exists uq_pay_ref on public.payments (school_id, lower(trim(reference)))
  where reference is not null and not voided and method in ('bank_transfer','pos');

-- ---------- triggers ----------
create or replace function public.set_invoice_no()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  new.invoice_no := 'INV-' || to_char(public.lagos_today(),'YYYY') || '-' || lpad(public.next_number(new.school_id,'invoice')::text, 5, '0');
  return new;
end $$;
drop trigger if exists trg_invoice_no on public.invoices;
create trigger trg_invoice_no before insert on public.invoices for each row execute function public.set_invoice_no();

create or replace function public.recalc_invoice()
returns trigger language plpgsql security definer set search_path = public as $$
declare iid uuid := coalesce(new.invoice_id, old.invoice_id);
begin
  update public.invoices set gross = coalesce((select sum(amount) from public.invoice_items where invoice_id = iid), 0) where id = iid;
  return null;
end $$;
drop trigger if exists trg_recalc_invoice on public.invoice_items;
create trigger trg_recalc_invoice after insert or update or delete on public.invoice_items for each row execute function public.recalc_invoice();

create or replace function public.validate_payment()
returns trigger language plpgsql security definer set search_path = public as $$
declare inv public.invoices; paid numeric;
begin
  select * into inv from public.invoices where id = new.invoice_id for update;
  if inv.id is null then raise exception 'Invoice not found'; end if;
  if inv.school_id <> new.school_id or inv.student_id <> new.student_id then raise exception 'Invoice does not match this student'; end if;
  select coalesce(sum(amount), 0) into paid from public.payments where invoice_id = new.invoice_id and not voided;
  if new.amount > inv.net - paid then
    raise exception 'The payment (%) is more than the outstanding balance (%)', new.amount, inv.net - paid;
  end if;
  if new.paid_on > public.lagos_today() then raise exception 'The payment date cannot be in the future'; end if;
  new.receipt_no := 'RCT-' || to_char(public.lagos_today(),'YYYY') || '-' || lpad(public.next_number(new.school_id,'receipt')::text, 5, '0');
  new.received_by := auth.uid(); new.voided := false; new.void_reason := null; new.voided_by := null; new.voided_at := null;
  return new;
end $$;
drop trigger if exists trg_validate_payment on public.payments;
create trigger trg_validate_payment before insert on public.payments for each row execute function public.validate_payment();

do $$ declare t text; begin
  foreach t in array array['fee_items','invoices','invoice_items','payments'] loop
    execute format('drop trigger if exists trg_audit_%1$s on public.%1$s', t);
    execute format('create trigger trg_audit_%1$s after insert or update or delete on public.%1$s for each row execute function public.log_audit()', t);
  end loop;
end $$;

-- ---------- RLS ----------
create or replace function public.invoice_visible(p_invoice uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.invoices i where i.id = p_invoice
    and (public.is_finance(i.school_id) or public.is_guardian_of(i.student_id) or public.is_self_student(i.student_id)));
$$;

alter table public.fee_items enable row level security;
alter table public.invoices enable row level security;
alter table public.invoice_items enable row level security;
alter table public.payments enable row level security;

drop policy if exists fee_items_all on public.fee_items;
create policy fee_items_all on public.fee_items for all to authenticated
  using (public.is_finance(school_id)) with check (public.is_finance(school_id));

drop policy if exists inv_select on public.invoices;
create policy inv_select on public.invoices for select to authenticated
  using (public.is_finance(school_id) or public.is_guardian_of(student_id) or public.is_self_student(student_id));
revoke insert, update, delete on public.invoices from authenticated;

drop policy if exists invitems_select on public.invoice_items;
create policy invitems_select on public.invoice_items for select to authenticated using (public.invoice_visible(invoice_id));
revoke insert, update, delete on public.invoice_items from authenticated;

drop policy if exists pay_select on public.payments;
create policy pay_select on public.payments for select to authenticated
  using (public.is_finance(school_id) or public.is_guardian_of(student_id) or public.is_self_student(student_id));
drop policy if exists pay_insert on public.payments;
create policy pay_insert on public.payments for insert to authenticated with check (public.is_finance(school_id));
revoke update, delete on public.payments from authenticated;

-- the bursar needs student names/classes and guardian contacts (not medical notes)
drop policy if exists students_select on public.students;
create policy students_select on public.students for select to authenticated using (
  public.is_super_admin() or public.is_school_manager(school_id)
  or public.has_school_role(school_id, array['bursar']::public.app_role[])
  or user_id = auth.uid() or public.is_guardian_of(id)
  or (current_class_id is not null and public.is_teacher_of_class(school_id, current_class_id)));
drop policy if exists guardians_select on public.guardians;
create policy guardians_select on public.guardians for select to authenticated
  using (public.is_super_admin() or public.is_school_manager(school_id)
         or public.has_school_role(school_id, array['bursar']::public.app_role[]) or user_id = auth.uid());
drop policy if exists sg_select on public.student_guardians;
create policy sg_select on public.student_guardians for select to authenticated
  using (public.is_super_admin() or public.is_school_manager(school_id)
         or public.has_school_role(school_id, array['bursar']::public.app_role[]) or public.is_guardian_of(student_id));

-- ---------- invoice summary (respects the caller's access) ----------
create or replace view public.invoice_summary with (security_invoker = true) as
select i.id, i.school_id, i.student_id, i.class_id, i.session_id, i.term_id, i.invoice_no,
       i.gross, i.discount, i.net, coalesce(pp.paid, 0) as paid, i.net - coalesce(pp.paid, 0) as balance
from public.invoices i
left join lateral (select sum(p.amount) as paid from public.payments p where p.invoice_id = i.id and not p.voided) pp on true;

-- ---------- functions ----------
create or replace function public.generate_invoices(p_class uuid, p_term uuid)
returns int language plpgsql security definer set search_path = public as $$
declare sch uuid; tm public.terms; n int := 0; s record; iid uuid;
begin
  select c.school_id into sch from public.classes c where c.id = p_class;
  select * into tm from public.terms where id = p_term;
  if sch is null or tm.id is null or tm.school_id <> sch then raise exception 'Class or term not found'; end if;
  if not public.is_finance(sch) then raise exception 'Not allowed'; end if;
  if not exists (select 1 from public.fee_items where class_id = p_class and term_id = p_term) then
    raise exception 'Add fee items for this class and term first';
  end if;
  for s in select st.id from public.students st
           where st.school_id = sch and st.current_class_id = p_class and st.status = 'active' and st.deleted_at is null
             and not exists (select 1 from public.invoices i where i.student_id = st.id and i.term_id = p_term) loop
    insert into public.invoices(school_id, student_id, class_id, session_id, term_id, invoice_no, created_by)
    values (sch, s.id, p_class, tm.session_id, p_term, 'pending', auth.uid()) returning id into iid;
    insert into public.invoice_items(school_id, invoice_id, name, amount)
      select sch, iid, f.name, f.amount from public.fee_items f where f.class_id = p_class and f.term_id = p_term;
    n := n + 1;
  end loop;
  return n;
end $$;
revoke all on function public.generate_invoices(uuid, uuid) from public, anon;
grant execute on function public.generate_invoices(uuid, uuid) to authenticated;

create or replace function public.add_invoice_item(p_invoice uuid, p_name text, p_amount numeric)
returns void language plpgsql security definer set search_path = public as $$
declare inv public.invoices;
begin
  select * into inv from public.invoices where id = p_invoice;
  if inv.id is null then raise exception 'Invoice not found'; end if;
  if not public.is_finance(inv.school_id) then raise exception 'Not allowed'; end if;
  if length(trim(coalesce(p_name,''))) < 2 or p_amount is null or p_amount <= 0 then raise exception 'Enter an item name and an amount above zero'; end if;
  insert into public.invoice_items(school_id, invoice_id, name, amount) values (inv.school_id, p_invoice, trim(p_name), p_amount);
end $$;
revoke all on function public.add_invoice_item(uuid, text, numeric) from public, anon;
grant execute on function public.add_invoice_item(uuid, text, numeric) to authenticated;

create or replace function public.set_discount(p_invoice uuid, p_amount numeric, p_reason text)
returns void language plpgsql security definer set search_path = public as $$
declare inv public.invoices; paid numeric;
begin
  select * into inv from public.invoices where id = p_invoice for update;
  if inv.id is null then raise exception 'Invoice not found'; end if;
  if not (public.is_super_admin() or public.is_school_manager(inv.school_id)) then raise exception 'Only the proprietor or administrator can approve discounts'; end if;
  if p_amount is null or p_amount < 0 then raise exception 'Enter a discount of zero or more'; end if;
  if p_amount > 0 and length(trim(coalesce(p_reason,''))) < 3 then raise exception 'Give a reason for the discount'; end if;
  if p_amount > inv.gross then raise exception 'The discount cannot be more than the invoice total'; end if;
  select coalesce(sum(amount),0) into paid from public.payments where invoice_id = p_invoice and not voided;
  if inv.gross - p_amount < paid then raise exception 'The discount would put the invoice below what has already been paid'; end if;
  update public.invoices set discount = p_amount, discount_reason = nullif(trim(coalesce(p_reason,'')),'') where id = p_invoice;
end $$;
revoke all on function public.set_discount(uuid, numeric, text) from public, anon;
grant execute on function public.set_discount(uuid, numeric, text) to authenticated;

create or replace function public.void_payment(p_payment uuid, p_reason text)
returns void language plpgsql security definer set search_path = public as $$
declare p public.payments;
begin
  select * into p from public.payments where id = p_payment for update;
  if p.id is null then raise exception 'Payment not found'; end if;
  if not (public.is_super_admin() or public.is_school_manager(p.school_id)) then raise exception 'Only the proprietor or administrator can void a payment'; end if;
  if p.voided then raise exception 'This payment is already voided'; end if;
  if length(trim(coalesce(p_reason,''))) < 5 then raise exception 'Give a reason (at least 5 characters)'; end if;
  update public.payments set voided = true, void_reason = trim(p_reason), voided_by = auth.uid(), voided_at = now() where id = p_payment;
end $$;
revoke all on function public.void_payment(uuid, text) from public, anon;
grant execute on function public.void_payment(uuid, text) to authenticated;

revoke all on all tables in schema public from anon;
