-- Migration 010: analytics functions for the owner dashboard. Run AFTER 001-009.
-- All functions check access first: only administrators/proprietor (fees: also the bursar).

create or replace function public.attendance_trend(p_school uuid, p_from date, p_to date)
returns table(att_date date, marks int, attended int, absent int)
language plpgsql stable security definer set search_path = public as $$
begin
  if not (public.is_super_admin() or public.is_school_manager(p_school)) then raise exception 'Not allowed'; end if;
  return query select a.att_date, count(*)::int, (count(*) filter (where a.status in ('present','late')))::int, (count(*) filter (where a.status = 'absent'))::int
    from public.attendance a where a.school_id = p_school and a.att_date between p_from and p_to group by a.att_date order by a.att_date;
end $$;

create or replace function public.attendance_by_class(p_school uuid, p_from date, p_to date)
returns table(class_id uuid, marks int, attended int)
language plpgsql stable security definer set search_path = public as $$
begin
  if not (public.is_super_admin() or public.is_school_manager(p_school)) then raise exception 'Not allowed'; end if;
  return query select a.class_id, count(*)::int, (count(*) filter (where a.status in ('present','late')))::int
    from public.attendance a where a.school_id = p_school and a.att_date between p_from and p_to group by a.class_id;
end $$;

create or replace function public.fee_summary(p_school uuid, p_term uuid)
returns table(invoices int, invoiced numeric, discounts numeric, collected numeric, outstanding numeric, fully_paid int)
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_finance(p_school) then raise exception 'Not allowed'; end if;
  return query
    select count(*)::int, coalesce(sum(s.net), 0), coalesce(sum(s.discount), 0), coalesce(sum(s.paid), 0), coalesce(sum(s.balance), 0),
           (count(*) filter (where s.balance <= 0))::int
    from public.invoice_summary s where s.school_id = p_school and s.term_id = p_term;
end $$;

create or replace function public.fee_trend(p_school uuid, p_from date)
returns table(month date, amount numeric)
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_finance(p_school) then raise exception 'Not allowed'; end if;
  return query select date_trunc('month', p.paid_on)::date, sum(p.amount) from public.payments p
    where p.school_id = p_school and not p.voided and p.paid_on >= p_from group by 1 order by 1;
end $$;

create or replace function public.subject_averages(p_school uuid, p_term uuid)
returns table(subject_name text, average numeric, students int)
language plpgsql stable security definer set search_path = public as $$
begin
  if not (public.is_super_admin() or public.is_school_manager(p_school)) then raise exception 'Not allowed'; end if;
  return query select sj.name, round(avg(sc.total), 1), count(distinct sc.student_id)::int
    from public.scores sc join public.subjects sj on sj.id = sc.subject_id
    where sc.school_id = p_school and sc.term_id = p_term group by sj.name order by 2 desc;
end $$;

create or replace function public.class_averages(p_school uuid, p_term uuid)
returns table(class_id uuid, average numeric, students int)
language plpgsql stable security definer set search_path = public as $$
begin
  if not (public.is_super_admin() or public.is_school_manager(p_school)) then raise exception 'Not allowed'; end if;
  return query select sc.class_id, round(avg(sc.total), 1), count(distinct sc.student_id)::int
    from public.scores sc where sc.school_id = p_school and sc.term_id = p_term group by sc.class_id;
end $$;

-- students whose term average is below a threshold: a prompt for a human to follow up, not a decision
create or replace function public.low_average_students(p_school uuid, p_term uuid, p_threshold numeric default 40)
returns table(student_id uuid, first_name text, last_name text, class_id uuid, average numeric, subjects int)
language plpgsql stable security definer set search_path = public as $$
begin
  if not (public.is_super_admin() or public.is_school_manager(p_school)) then raise exception 'Not allowed'; end if;
  return query select s.id, s.first_name, s.last_name, s.current_class_id, round(avg(sc.total), 1), count(*)::int
    from public.scores sc join public.students s on s.id = sc.student_id
    where sc.school_id = p_school and sc.term_id = p_term group by s.id, s.first_name, s.last_name, s.current_class_id
    having avg(sc.total) < p_threshold order by 5 limit 100;
end $$;

create or replace function public.admission_funnel(p_school uuid)
returns table(status text, n int)
language plpgsql stable security definer set search_path = public as $$
begin
  if not (public.is_super_admin() or public.is_school_manager(p_school)) then raise exception 'Not allowed'; end if;
  return query select a.status, count(*)::int from public.admission_applications a where a.school_id = p_school group by a.status;
end $$;

do $$ declare f text; begin
  foreach f in array array[
    'attendance_trend(uuid,date,date)','attendance_by_class(uuid,date,date)','fee_summary(uuid,uuid)','fee_trend(uuid,date)',
    'subject_averages(uuid,uuid)','class_averages(uuid,uuid)','low_average_students(uuid,uuid,numeric)','admission_funnel(uuid)'] loop
    execute format('revoke all on function public.%s from public, anon', f);
    execute format('grant execute on function public.%s to authenticated', f);
  end loop;
end $$;
