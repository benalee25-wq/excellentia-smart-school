-- Migration 012: learning materials, assignments, submissions and marking. Run AFTER 001-011.
-- Files live in a PRIVATE bucket and open only through short-lived signed links.

alter table public.notifications drop constraint if exists notifications_kind_check;
alter table public.notifications add constraint notifications_kind_check
  check (kind in ('absence','payment','invoice','report','announcement','general','assignment','material'));

create table if not exists public.resources (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null references public.schools(id) on delete cascade,
  class_id uuid not null references public.classes(id) on delete cascade,
  subject_id uuid not null references public.subjects(id) on delete cascade,
  session_id uuid not null references public.academic_sessions(id) on delete cascade,
  term_id uuid references public.terms(id) on delete set null,
  title text not null check (char_length(title) between 3 and 120),
  topic text,
  description text,
  kind text not null check (kind in ('file','link','note')),
  file_path text,
  file_name text,
  link_url text,
  body text,
  published boolean not null default true,
  created_by uuid,
  created_by_name text,
  created_at timestamptz not null default now(),
  check ((kind = 'file' and file_path is not null) or (kind = 'link' and link_url ~* '^https?://') or (kind = 'note' and nullif(trim(body), '') is not null))
);
create index if not exists idx_res_class on public.resources(class_id, subject_id, created_at desc);

create table if not exists public.assignments (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null references public.schools(id) on delete cascade,
  class_id uuid not null references public.classes(id) on delete cascade,
  subject_id uuid not null references public.subjects(id) on delete cascade,
  session_id uuid not null references public.academic_sessions(id) on delete cascade,
  term_id uuid references public.terms(id) on delete set null,
  title text not null check (char_length(title) between 3 and 120),
  instructions text,
  due_at timestamptz,
  max_score numeric(5,1) not null default 10 check (max_score > 0 and max_score <= 100),
  allow_text boolean not null default true,
  allow_file boolean not null default true,
  attachment_path text,
  attachment_name text,
  published boolean not null default true,
  closed boolean not null default false,
  created_by uuid,
  created_by_name text,
  created_at timestamptz not null default now(),
  check (allow_text or allow_file)
);
create index if not exists idx_asg_class on public.assignments(class_id, created_at desc);

create table if not exists public.submissions (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null references public.schools(id) on delete cascade,
  assignment_id uuid not null references public.assignments(id) on delete cascade,
  student_id uuid not null references public.students(id) on delete cascade,
  text_answer text,
  file_path text,
  file_name text,
  submitted_at timestamptz not null default now(),
  resubmitted_at timestamptz,
  is_late boolean not null default false,
  score numeric(5,1) check (score >= 0),
  feedback text,
  graded_by uuid,
  graded_at timestamptz,
  unique (assignment_id, student_id),
  check (nullif(trim(coalesce(text_answer, '')), '') is not null or file_path is not null)
);
create index if not exists idx_sub_student on public.submissions(student_id);

-- ---------- helpers ----------
create or replace function public.class_content_visible(p_school uuid, p_class uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.students s where s.school_id = p_school and s.current_class_id = p_class
                 and (public.is_self_student(s.id) or public.is_guardian_of(s.id)));
$$;
create or replace function public.assignment_teacher(p_assignment uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.assignments a where a.id = p_assignment
                 and public.is_teacher_for(a.school_id, a.class_id, a.subject_id, a.session_id));
$$;

create or replace function public.validate_class_content()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if not exists (select 1 from public.classes where id = new.class_id and school_id = new.school_id)
     or not exists (select 1 from public.subjects where id = new.subject_id and school_id = new.school_id)
     or not exists (select 1 from public.academic_sessions where id = new.session_id and school_id = new.school_id) then
    raise exception 'Class, subject or session does not belong to this school';
  end if;
  if tg_op = 'INSERT' then
    new.created_by := auth.uid();
    select full_name into new.created_by_name from public.profiles where id = auth.uid();
  end if;
  return new;
end $$;
drop trigger if exists trg_validate_resources on public.resources;
create trigger trg_validate_resources before insert or update on public.resources for each row execute function public.validate_class_content();
drop trigger if exists trg_validate_assignments on public.assignments;
create trigger trg_validate_assignments before insert or update on public.assignments for each row execute function public.validate_class_content();

drop trigger if exists trg_audit_assignments on public.assignments;
create trigger trg_audit_assignments after insert or update or delete on public.assignments for each row execute function public.log_audit();

-- ---------- notifications ----------
create or replace function public.notify_class(p_class uuid, p_kind text, p_title text, p_body text, p_view text)
returns void language plpgsql security definer set search_path = public as $$
declare s record;
begin
  for s in select id from public.students where current_class_id = p_class and status = 'active' and deleted_at is null loop
    perform public.notify_guardians(s.id, p_kind, p_title, p_body, p_view, true);
  end loop;
end $$;
revoke all on function public.notify_class(uuid, text, text, text, text) from public, anon, authenticated;

create or replace function public.trg_notify_assignment()
returns trigger language plpgsql security definer set search_path = public as $$
declare sj text;
begin
  if new.published and (tg_op = 'INSERT' or not old.published) then
    select name into sj from public.subjects where id = new.subject_id;
    perform public.notify_class(new.class_id, 'assignment', 'New assignment: ' || new.title,
      sj || case when new.due_at is not null then ', due ' || to_char(new.due_at at time zone 'Africa/Lagos', 'DD Mon HH24:MI') else '' end, 'classwork');
  end if;
  return null;
end $$;
drop trigger if exists trg_notify_assignment on public.assignments;
create trigger trg_notify_assignment after insert or update of published on public.assignments for each row execute function public.trg_notify_assignment();

create or replace function public.trg_notify_graded()
returns trigger language plpgsql security definer set search_path = public as $$
declare a public.assignments;
begin
  if new.graded_at is not null and new.graded_at is distinct from old.graded_at then
    select * into a from public.assignments where id = new.assignment_id;
    perform public.notify_guardians(new.student_id, 'assignment', 'Assignment marked', '"' || a.title || '": ' || new.score || ' out of ' || a.max_score, 'classwork', true);
  end if;
  return null;
end $$;
drop trigger if exists trg_notify_graded on public.submissions;
create trigger trg_notify_graded after update on public.submissions for each row execute function public.trg_notify_graded();

-- ---------- RLS ----------
alter table public.resources enable row level security;
alter table public.assignments enable row level security;
alter table public.submissions enable row level security;

drop policy if exists res_select on public.resources;
create policy res_select on public.resources for select to authenticated using (
  public.is_super_admin() or public.is_school_manager(school_id) or public.is_teacher_of_class(school_id, class_id)
  or (published and public.class_content_visible(school_id, class_id)));
drop policy if exists res_write on public.resources;
create policy res_write on public.resources for all to authenticated
  using (public.is_super_admin() or public.is_school_manager(school_id) or public.is_teacher_for(school_id, class_id, subject_id, session_id))
  with check (public.is_super_admin() or public.is_school_manager(school_id) or public.is_teacher_for(school_id, class_id, subject_id, session_id));

drop policy if exists asg_select on public.assignments;
create policy asg_select on public.assignments for select to authenticated using (
  public.is_super_admin() or public.is_school_manager(school_id) or public.is_teacher_of_class(school_id, class_id)
  or (published and public.class_content_visible(school_id, class_id)));
drop policy if exists asg_write on public.assignments;
create policy asg_write on public.assignments for all to authenticated
  using (public.is_super_admin() or public.is_school_manager(school_id) or public.is_teacher_for(school_id, class_id, subject_id, session_id))
  with check (public.is_super_admin() or public.is_school_manager(school_id) or public.is_teacher_for(school_id, class_id, subject_id, session_id));

drop policy if exists sub_select on public.submissions;
create policy sub_select on public.submissions for select to authenticated using (
  public.is_super_admin() or public.is_school_manager(school_id) or public.assignment_teacher(assignment_id)
  or public.is_self_student(student_id) or public.is_guardian_of(student_id));
revoke insert, update, delete on public.submissions from authenticated;   -- writes go through the functions below

-- ---------- submit and mark ----------
create or replace function public.submit_assignment(p_assignment uuid, p_text text, p_file_path text, p_file_name text)
returns uuid language plpgsql security definer set search_path = public as $$
declare a public.assignments; stu uuid; sub public.submissions; sid uuid; late boolean; txt text; fp text; fn text;
begin
  select * into a from public.assignments where id = p_assignment;
  if a.id is null or not a.published then raise exception 'Assignment not found'; end if;
  if a.closed then raise exception 'This assignment is closed'; end if;
  select s.id into stu from public.students s where s.user_id = auth.uid() and s.school_id = a.school_id
    and s.current_class_id = a.class_id and s.status = 'active' and s.deleted_at is null;
  if stu is null then raise exception 'Only students in this class can submit work'; end if;
  txt := case when a.allow_text then nullif(trim(coalesce(p_text, '')), '') end;
  fp := case when a.allow_file then p_file_path end; fn := case when a.allow_file then p_file_name end;
  if fp is not null and fp not like ('s/' || a.school_id || '/' || stu || '/' || a.id || '/%') then raise exception 'Invalid file'; end if;
  if txt is null and fp is null then raise exception 'Write an answer or attach a file'; end if;
  if length(coalesce(txt, '')) > 20000 then raise exception 'The written answer is too long'; end if;
  select * into sub from public.submissions where assignment_id = a.id and student_id = stu;
  if sub.id is not null and sub.graded_at is not null then raise exception 'This work has already been marked'; end if;
  late := a.due_at is not null and now() > a.due_at;
  if sub.id is null then
    insert into public.submissions(school_id, assignment_id, student_id, text_answer, file_path, file_name, is_late)
    values (a.school_id, a.id, stu, txt, fp, fn, late) returning id into sid;
  else
    update public.submissions set text_answer = txt, file_path = fp, file_name = fn, resubmitted_at = now(), is_late = late where id = sub.id;
    sid := sub.id;
  end if;
  return sid;
end $$;
revoke all on function public.submit_assignment(uuid, text, text, text) from public, anon;
grant execute on function public.submit_assignment(uuid, text, text, text) to authenticated;

create or replace function public.grade_submission(p_submission uuid, p_score numeric, p_feedback text)
returns void language plpgsql security definer set search_path = public as $$
declare sub public.submissions; a public.assignments;
begin
  select * into sub from public.submissions where id = p_submission;
  if sub.id is null then raise exception 'Submission not found'; end if;
  select * into a from public.assignments where id = sub.assignment_id;
  if not (public.is_super_admin() or public.is_school_manager(a.school_id) or public.is_teacher_for(a.school_id, a.class_id, a.subject_id, a.session_id)) then raise exception 'Not allowed'; end if;
  if p_score is null or p_score < 0 or p_score > a.max_score then raise exception 'The score must be between 0 and %', a.max_score; end if;
  update public.submissions set score = p_score, feedback = nullif(trim(coalesce(p_feedback, '')), ''), graded_by = auth.uid(), graded_at = now() where id = p_submission;
end $$;
revoke all on function public.grade_submission(uuid, numeric, text) from public, anon;
grant execute on function public.grade_submission(uuid, numeric, text) to authenticated;

-- ---------- file storage (private bucket) ----------
create or replace function public.learning_file_visible(p_name text)
returns boolean language plpgsql stable security definer set search_path = public as $$
declare k text := split_part(p_name, '/', 1); sch uuid := public.safe_uuid(split_part(p_name, '/', 2)); x uuid := public.safe_uuid(split_part(p_name, '/', 3));
begin
  if sch is null or x is null then return false; end if;
  if public.is_super_admin() or public.is_school_manager(sch) then return true; end if;
  if k in ('m', 'a') then return public.is_teacher_of_class(sch, x) or public.class_content_visible(sch, x); end if;
  if k = 's' then
    return public.is_self_student(x) or public.is_guardian_of(x)
      or exists (select 1 from public.students s where s.id = x and s.school_id = sch and s.current_class_id is not null and public.is_teacher_of_class(sch, s.current_class_id));
  end if;
  return false;
end $$;

create or replace function public.learning_file_writable(p_name text)
returns boolean language plpgsql stable security definer set search_path = public as $$
declare k text := split_part(p_name, '/', 1); sch uuid := public.safe_uuid(split_part(p_name, '/', 2)); x uuid := public.safe_uuid(split_part(p_name, '/', 3));
begin
  if sch is null or x is null then return false; end if;
  if k in ('m', 'a') then
    return exists (select 1 from public.classes c where c.id = x and c.school_id = sch)
       and (public.is_super_admin() or public.is_school_manager(sch) or public.is_teacher_of_class(sch, x));
  end if;
  if k = 's' then return public.is_self_student(x) and exists (select 1 from public.students s where s.id = x and s.school_id = sch); end if;
  return false;
end $$;

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types) values
  ('learning-files', 'learning-files', false, 8388608, array['application/pdf','image/jpeg','image/png','image/webp','text/plain','audio/mpeg',
    'application/msword','application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/vnd.ms-powerpoint','application/vnd.openxmlformats-officedocument.presentationml.presentation',
    'application/vnd.ms-excel','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'])
on conflict (id) do update set file_size_limit = excluded.file_size_limit, allowed_mime_types = excluded.allowed_mime_types, public = false;

drop policy if exists "ssms_lf_read" on storage.objects;
create policy "ssms_lf_read" on storage.objects for select to authenticated using (bucket_id = 'learning-files' and public.learning_file_visible(name));
drop policy if exists "ssms_lf_insert" on storage.objects;
create policy "ssms_lf_insert" on storage.objects for insert to authenticated with check (bucket_id = 'learning-files' and public.learning_file_writable(name));
drop policy if exists "ssms_lf_update" on storage.objects;
create policy "ssms_lf_update" on storage.objects for update to authenticated using (bucket_id = 'learning-files' and public.learning_file_writable(name)) with check (bucket_id = 'learning-files' and public.learning_file_writable(name));
drop policy if exists "ssms_lf_delete" on storage.objects;
create policy "ssms_lf_delete" on storage.objects for delete to authenticated using (bucket_id = 'learning-files' and public.learning_file_writable(name));

revoke all on all tables in schema public from anon;
