-- Migration 008: in-app notifications and announcements. Run AFTER 001-007.
-- Delivery is IN-APP ONLY. Email / SMS / WhatsApp need provider accounts and are not included.

create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null references public.schools(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  kind text not null default 'general' check (kind in ('absence','payment','invoice','report','announcement','general')),
  title text not null,
  body text,
  link_view text,
  read_at timestamptz,
  created_at timestamptz not null default now()
);
create index if not exists idx_notif_user on public.notifications(user_id, created_at desc);
create index if not exists idx_notif_unread on public.notifications(user_id) where read_at is null;

create table if not exists public.announcements (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null references public.schools(id) on delete cascade,
  title text not null check (char_length(title) between 3 and 120),
  body text not null check (char_length(body) between 3 and 2000),
  audience text[] not null check (cardinality(audience) > 0 and audience <@ array['parent','student','staff']),
  is_urgent boolean not null default false,
  created_by uuid,
  created_at timestamptz not null default now()
);
create index if not exists idx_ann_school on public.announcements(school_id, created_at desc);

-- ---------- internal helpers ----------
create or replace function public.notify_guardians(p_student uuid, p_kind text, p_title text, p_body text, p_view text, p_include_student boolean default false)
returns void language plpgsql security definer set search_path = public as $$
declare sch uuid; ids uuid[];
begin
  select school_id into sch from public.students where id = p_student;
  if sch is null then return; end if;
  select array_agg(distinct g.user_id) into ids from public.student_guardians sg
    join public.guardians g on g.id = sg.guardian_id where sg.student_id = p_student and g.user_id is not null;
  if p_include_student then
    ids := coalesce(ids, '{}') || coalesce((select array_agg(user_id) from public.students where id = p_student and user_id is not null), '{}');
  end if;
  if ids is null or cardinality(ids) = 0 then return; end if;
  insert into public.notifications(school_id, user_id, kind, title, body, link_view)
  select distinct sch, u, p_kind, p_title, p_body, p_view from unnest(ids) u;
end $$;
revoke all on function public.notify_guardians(uuid, text, text, text, text, boolean) from public, anon, authenticated;

-- ---------- automatic notifications ----------
create or replace function public.trg_notify_absence()
returns trigger language plpgsql security definer set search_path = public as $$
declare nm text;
begin
  if new.status = 'absent' and (tg_op = 'INSERT' or old.status is distinct from 'absent') and new.att_date >= public.lagos_today() - 2 then
    select first_name || ' ' || last_name into nm from public.students where id = new.student_id;
    perform public.notify_guardians(new.student_id, 'absence', 'Absence recorded', nm || ' was marked absent on ' || to_char(new.att_date, 'DD Mon YYYY') || '.', 'myattendance');
  end if;
  return null;
end $$;
drop trigger if exists trg_notify_absence on public.attendance;
create trigger trg_notify_absence after insert or update on public.attendance for each row execute function public.trg_notify_absence();

create or replace function public.trg_notify_payment()
returns trigger language plpgsql security definer set search_path = public as $$
declare nm text; net numeric; paid numeric; amt text;
begin
  select first_name || ' ' || last_name into nm from public.students where id = new.student_id;
  amt := '₦' || to_char(new.amount, 'FM999,999,999,990.00');
  if tg_op = 'INSERT' then
    select i.net into net from public.invoices i where i.id = new.invoice_id;
    select coalesce(sum(amount), 0) into paid from public.payments where invoice_id = new.invoice_id and not voided;
    perform public.notify_guardians(new.student_id, 'payment', 'Payment received',
      amt || ' received for ' || nm || '. Receipt ' || new.receipt_no || '. Balance: ₦' || to_char(net - paid, 'FM999,999,999,990.00') || '.', 'myfees');
  elsif new.voided and not old.voided then
    perform public.notify_guardians(new.student_id, 'payment', 'Payment voided', 'Receipt ' || new.receipt_no || ' (' || amt || ') for ' || nm || ' was voided by the school. Contact the bursar for details.', 'myfees');
  end if;
  return null;
end $$;
drop trigger if exists trg_notify_payment on public.payments;
create trigger trg_notify_payment after insert or update of voided on public.payments for each row execute function public.trg_notify_payment();

create or replace function public.trg_notify_invoice()
returns trigger language plpgsql security definer set search_path = public as $$
declare nm text; tn text;
begin
  select first_name || ' ' || last_name into nm from public.students where id = new.student_id;
  select name into tn from public.terms where id = new.term_id;
  perform public.notify_guardians(new.student_id, 'invoice', 'New fee invoice', 'A fee invoice has been issued for ' || nm || ' (' || tn || '). Open Fees to view it.', 'myfees', true);
  return null;
end $$;
drop trigger if exists trg_notify_invoice on public.invoices;
create trigger trg_notify_invoice after insert on public.invoices for each row execute function public.trg_notify_invoice();

-- publishing a class's results also notifies parents and students
create or replace function public.set_report_status(p_class uuid, p_term uuid, p_status text)
returns int language plpgsql security definer set search_path = public as $$
declare sch uuid; n int; tn text; r record; nm text;
begin
  if p_status not in ('draft','published') then raise exception 'Invalid status'; end if;
  select c.school_id into sch from public.classes c where c.id = p_class;
  if sch is null then raise exception 'Class not found'; end if;
  if not (public.is_super_admin() or public.is_school_manager(sch)) then raise exception 'Not allowed'; end if;
  if p_status = 'published' then
    select name into tn from public.terms where id = p_term;
    for r in select distinct s.student_id from public.scores s
             where s.class_id = p_class and s.term_id = p_term and not public.report_published(s.student_id, p_term) loop
      select first_name || ' ' || last_name into nm from public.students where id = r.student_id;
      perform public.notify_guardians(r.student_id, 'report', 'Report card published', 'The ' || tn || ' report card for ' || nm || ' is now available.', 'myreports', true);
    end loop;
  end if;
  insert into public.report_cards(school_id, student_id, class_id, session_id, term_id, status, published_at)
  select distinct s.school_id, s.student_id, p_class, s.session_id, p_term, p_status, case when p_status = 'published' then now() end
  from public.scores s where s.class_id = p_class and s.term_id = p_term
  on conflict (student_id, term_id) do update set
    status = excluded.status, published_at = excluded.published_at, class_id = excluded.class_id, updated_at = now();
  get diagnostics n = row_count;
  return n;
end $$;
revoke all on function public.set_report_status(uuid, uuid, text) from public, anon;
grant execute on function public.set_report_status(uuid, uuid, text) to authenticated;

-- ---------- announcements ----------
create or replace function public.can_read_announcement(p_school uuid, p_audience text[])
returns boolean language sql stable security definer set search_path = public as $$
  select public.is_super_admin() or public.is_school_manager(p_school) or exists (
    select 1 from public.school_memberships m where m.user_id = auth.uid() and m.school_id = p_school and m.is_active
      and ((m.role = 'parent' and 'parent' = any(p_audience)) or (m.role = 'student' and 'student' = any(p_audience))
           or (m.role not in ('parent','student') and 'staff' = any(p_audience))));
$$;

create or replace function public.post_announcement(p_school uuid, p_title text, p_body text, p_audience text[], p_urgent boolean default false)
returns int language plpgsql security definer set search_path = public as $$
declare n int;
begin
  if not (public.is_super_admin() or public.is_school_manager(p_school)) then raise exception 'Not allowed'; end if;
  if length(trim(coalesce(p_title,''))) < 3 or length(trim(coalesce(p_body,''))) < 3 then raise exception 'Enter a title and a message'; end if;
  if p_audience is null or cardinality(p_audience) = 0 then raise exception 'Choose who should receive this'; end if;
  insert into public.announcements(school_id, title, body, audience, is_urgent, created_by)
  values (p_school, trim(p_title), trim(p_body), p_audience, coalesce(p_urgent, false), auth.uid());
  insert into public.notifications(school_id, user_id, kind, title, body, link_view)
  select distinct p_school, m.user_id, 'announcement', case when p_urgent then 'URGENT: ' else '' end || trim(p_title), left(trim(p_body), 160), 'announcements'
  from public.school_memberships m join public.profiles p on p.id = m.user_id
  where m.school_id = p_school and m.is_active and p.is_active and m.user_id <> auth.uid()
    and ((m.role = 'parent' and 'parent' = any(p_audience)) or (m.role = 'student' and 'student' = any(p_audience))
         or (m.role not in ('parent','student') and 'staff' = any(p_audience)));
  get diagnostics n = row_count;
  return n;
end $$;
revoke all on function public.post_announcement(uuid, text, text, text[], boolean) from public, anon;
grant execute on function public.post_announcement(uuid, text, text, text[], boolean) to authenticated;

-- ---------- RLS ----------
alter table public.notifications enable row level security;
alter table public.announcements enable row level security;

drop policy if exists notif_select on public.notifications;
create policy notif_select on public.notifications for select to authenticated using (user_id = auth.uid());
drop policy if exists notif_update on public.notifications;
create policy notif_update on public.notifications for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
revoke insert, update, delete on public.notifications from authenticated, anon;
grant update (read_at) on public.notifications to authenticated;

drop policy if exists ann_select on public.announcements;
create policy ann_select on public.announcements for select to authenticated using (public.can_read_announcement(school_id, audience));
drop policy if exists ann_delete on public.announcements;
create policy ann_delete on public.announcements for delete to authenticated using (public.is_super_admin() or public.is_school_manager(school_id));
revoke insert, update on public.announcements from authenticated, anon;

revoke all on all tables in schema public from anon;
