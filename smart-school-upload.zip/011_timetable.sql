-- Migration 011: periods, rooms and weekly timetable with clash detection. Run AFTER 001-010.

create table if not exists public.periods (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null references public.schools(id) on delete cascade,
  name text not null check (char_length(name) between 1 and 40),
  start_time time not null,
  end_time time not null,
  is_break boolean not null default false,
  sort_order int not null,
  check (end_time > start_time),
  unique (school_id, sort_order)
);

create table if not exists public.rooms (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null references public.schools(id) on delete cascade,
  name text not null check (char_length(name) between 1 and 60),
  unique (school_id, name)
);

create table if not exists public.timetable_entries (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null references public.schools(id) on delete cascade,
  session_id uuid not null references public.academic_sessions(id) on delete cascade,
  class_id uuid not null references public.classes(id) on delete cascade,
  day int not null check (day between 1 and 6),
  period_id uuid not null references public.periods(id) on delete cascade,
  subject_id uuid not null references public.subjects(id) on delete cascade,
  staff_id uuid references public.staff(id) on delete set null,
  room_id uuid references public.rooms(id) on delete set null,
  created_at timestamptz not null default now(),
  unique (session_id, class_id, day, period_id)          -- a class can only have one lesson per slot
);
create index if not exists idx_tt_staff on public.timetable_entries(session_id, day, period_id, staff_id);
create index if not exists idx_tt_class on public.timetable_entries(class_id, session_id);

-- periods must not overlap in time
create or replace function public.validate_period()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if exists (select 1 from public.periods p where p.school_id = new.school_id and p.id <> new.id
             and new.start_time < p.end_time and new.end_time > p.start_time) then
    raise exception 'This time overlaps another period';
  end if;
  return new;
end $$;
drop trigger if exists trg_validate_period on public.periods;
create trigger trg_validate_period before insert or update on public.periods for each row execute function public.validate_period();

-- every lesson: same school, not in a break, no teacher or room double-booking
create or replace function public.validate_entry()
returns trigger language plpgsql security definer set search_path = public as $$
declare clash text;
begin
  if not exists (select 1 from public.classes where id = new.class_id and school_id = new.school_id)
     or not exists (select 1 from public.academic_sessions where id = new.session_id and school_id = new.school_id)
     or not exists (select 1 from public.subjects where id = new.subject_id and school_id = new.school_id)
     or not exists (select 1 from public.periods where id = new.period_id and school_id = new.school_id) then
    raise exception 'Class, session, subject or period does not belong to this school';
  end if;
  if exists (select 1 from public.periods where id = new.period_id and is_break) then raise exception 'You cannot put a lesson in a break'; end if;
  if new.staff_id is not null then
    if not exists (select 1 from public.staff where id = new.staff_id and school_id = new.school_id and status <> 'left') then raise exception 'Choose a current staff member of this school'; end if;
    select s.full_name || ' is already teaching ' || c.name || coalesce(' ' || c.arm, '') || ' at this time' into clash
      from public.timetable_entries e join public.staff s on s.id = e.staff_id join public.classes c on c.id = e.class_id
      where e.session_id = new.session_id and e.day = new.day and e.period_id = new.period_id and e.staff_id = new.staff_id and e.id <> new.id limit 1;
    if clash is not null then raise exception 'Clash: %', clash; end if;
  end if;
  if new.room_id is not null then
    if not exists (select 1 from public.rooms where id = new.room_id and school_id = new.school_id) then raise exception 'Room does not belong to this school'; end if;
    select r.name || ' is already used by ' || c.name || coalesce(' ' || c.arm, '') || ' at this time' into clash
      from public.timetable_entries e join public.rooms r on r.id = e.room_id join public.classes c on c.id = e.class_id
      where e.session_id = new.session_id and e.day = new.day and e.period_id = new.period_id and e.room_id = new.room_id and e.id <> new.id limit 1;
    if clash is not null then raise exception 'Clash: %', clash; end if;
  end if;
  return new;
end $$;
drop trigger if exists trg_validate_entry on public.timetable_entries;
create trigger trg_validate_entry before insert or update on public.timetable_entries for each row execute function public.validate_entry();

drop trigger if exists trg_audit_timetable_entries on public.timetable_entries;
create trigger trg_audit_timetable_entries after insert or update or delete on public.timetable_entries for each row execute function public.log_audit();

-- ---------- RLS ----------
alter table public.periods enable row level security;
alter table public.rooms enable row level security;
alter table public.timetable_entries enable row level security;

do $$ declare t text; begin
  foreach t in array array['periods','rooms','timetable_entries'] loop
    execute format('drop policy if exists %1$s_select on public.%1$s', t);
    execute format('create policy %1$s_select on public.%1$s for select to authenticated using (public.is_super_admin() or public.is_school_member(school_id))', t);
    execute format('drop policy if exists %1$s_write on public.%1$s', t);
    execute format('create policy %1$s_write on public.%1$s for all to authenticated using (public.is_super_admin() or public.is_school_manager(school_id)) with check (public.is_super_admin() or public.is_school_manager(school_id))', t);
  end loop;
end $$;

-- ---------- read functions (include names; parents see only their child's class) ----------
create or replace function public.class_timetable(p_class uuid, p_session uuid)
returns table(entry_id uuid, day int, period_id uuid, subject_id uuid, subject_name text, staff_id uuid, teacher_name text, room_id uuid, room_name text, class_id uuid, class_name text)
language plpgsql stable security definer set search_path = public as $$
declare sch uuid;
begin
  select c.school_id into sch from public.classes c where c.id = p_class;
  if sch is null then raise exception 'Class not found'; end if;
  if not (public.is_super_admin() or public.is_school_manager(sch)
          or exists (select 1 from public.school_memberships m where m.user_id = auth.uid() and m.school_id = sch and m.is_active and m.role not in ('parent','student'))
          or exists (select 1 from public.students s where s.current_class_id = p_class and (public.is_guardian_of(s.id) or public.is_self_student(s.id)))) then
    raise exception 'Not allowed';
  end if;
  return query
    select e.id, e.day, e.period_id, e.subject_id, sj.name, e.staff_id, st.full_name, e.room_id, r.name, e.class_id, (c.name || coalesce(' ' || c.arm, ''))
    from public.timetable_entries e
    join public.subjects sj on sj.id = e.subject_id join public.classes c on c.id = e.class_id
    left join public.staff st on st.id = e.staff_id left join public.rooms r on r.id = e.room_id
    where e.class_id = p_class and e.session_id = p_session;
end $$;
revoke all on function public.class_timetable(uuid, uuid) from public, anon;
grant execute on function public.class_timetable(uuid, uuid) to authenticated;

create or replace function public.my_timetable(p_session uuid)
returns table(entry_id uuid, day int, period_id uuid, subject_id uuid, subject_name text, staff_id uuid, teacher_name text, room_id uuid, room_name text, class_id uuid, class_name text)
language sql stable security definer set search_path = public as $$
  select e.id, e.day, e.period_id, e.subject_id, sj.name, e.staff_id, st.full_name, e.room_id, r.name, e.class_id, (c.name || coalesce(' ' || c.arm, ''))
  from public.timetable_entries e
  join public.staff st on st.id = e.staff_id and st.user_id = auth.uid()
  join public.subjects sj on sj.id = e.subject_id join public.classes c on c.id = e.class_id
  left join public.rooms r on r.id = e.room_id
  where e.session_id = p_session;
$$;
revoke all on function public.my_timetable(uuid) from public, anon;
grant execute on function public.my_timetable(uuid) to authenticated;

revoke all on all tables in schema public from anon;
