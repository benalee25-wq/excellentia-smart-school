-- Migration 013: security hardening from the security review. Run AFTER 001-012.
-- Safe to run more than once.

-- ============ 1. Functions: nothing is callable by anonymous visitors except the two public admission functions ============
revoke all on all functions in schema public from public, anon;
alter default privileges in schema public revoke execute on functions from public, anon;

-- ============ 2. Simple rate limiter (used by the public admission form) ============
create table if not exists public.api_throttle (
  key text primary key,
  window_start timestamptz not null default now(),
  n int not null default 0
);
alter table public.api_throttle enable row level security;      -- no policies: internal only
revoke all on public.api_throttle from anon, authenticated;

create or replace function public.throttle(p_key text, p_limit int, p_seconds int)
returns void language plpgsql security definer set search_path = public as $$
declare cur int;
begin
  if random() < 0.01 then delete from public.api_throttle where window_start < now() - interval '1 day'; end if;
  insert into public.api_throttle as t (key, window_start, n) values (p_key, now(), 1)
  on conflict (key) do update set
    n = case when now() - t.window_start > make_interval(secs => p_seconds) then 1 else t.n + 1 end,
    window_start = case when now() - t.window_start > make_interval(secs => p_seconds) then now() else t.window_start end
  returning n into cur;
  if cur > p_limit then raise exception 'Too many attempts. Please try again later.'; end if;
end $$;
revoke all on function public.throttle(text, int, int) from public, anon, authenticated;

-- ============ 3. Tenant integrity: every linked record must belong to the same school ============
create or replace function public.enforce_same_school()
returns trigger language plpgsql security definer set search_path = public as $$
declare a text; col text; tbl text; val uuid; ok boolean;
begin
  foreach a in array tg_argv loop
    col := split_part(a, ':', 1); tbl := split_part(a, ':', 2);
    val := nullif(to_jsonb(new) ->> col, '')::uuid;
    if val is not null then
      execute format('select exists (select 1 from public.%I where id = $1 and school_id = $2)', tbl) into ok using val, new.school_id;
      if not ok then raise exception 'A linked record does not belong to this school (%)', col; end if;
    end if;
  end loop;
  return new;
end $$;
revoke all on function public.enforce_same_school() from public, anon, authenticated;

drop trigger if exists trg_same_school on public.enrollments;
create trigger trg_same_school before insert or update on public.enrollments for each row execute function public.enforce_same_school('student_id:students', 'class_id:classes', 'session_id:academic_sessions');
drop trigger if exists trg_same_school on public.student_guardians;
create trigger trg_same_school before insert or update on public.student_guardians for each row execute function public.enforce_same_school('student_id:students', 'guardian_id:guardians');
drop trigger if exists trg_same_school on public.teacher_assignments;
create trigger trg_same_school before insert or update on public.teacher_assignments for each row execute function public.enforce_same_school('staff_id:staff', 'class_id:classes', 'subject_id:subjects', 'session_id:academic_sessions');
drop trigger if exists trg_same_school on public.fee_items;
create trigger trg_same_school before insert or update on public.fee_items for each row execute function public.enforce_same_school('class_id:classes', 'term_id:terms', 'session_id:academic_sessions');
drop trigger if exists trg_same_school on public.terms;
create trigger trg_same_school before insert or update on public.terms for each row execute function public.enforce_same_school('session_id:academic_sessions');
drop trigger if exists trg_same_school on public.students;
create trigger trg_same_school before insert or update on public.students for each row execute function public.enforce_same_school('current_class_id:classes');
drop trigger if exists trg_same_school on public.student_sensitive;
create trigger trg_same_school before insert or update on public.student_sensitive for each row execute function public.enforce_same_school('student_id:students');
drop trigger if exists trg_same_school on public.admission_applications;
create trigger trg_same_school before insert or update on public.admission_applications for each row execute function public.enforce_same_school('student_id:students');
drop trigger if exists trg_same_school on public.school_memberships;
create trigger trg_same_school before insert or update on public.school_memberships for each row execute function public.enforce_same_school('branch_id:branches');

-- ============ 4. Access follows the membership: deactivating a person now really cuts off their access ============
create or replace function public.is_guardian_of(p_student uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.student_guardians sg
    join public.guardians g on g.id = sg.guardian_id
    join public.students s on s.id = sg.student_id and s.school_id = g.school_id
    join public.profiles p on p.id = g.user_id and p.is_active
    join public.school_memberships m on m.user_id = g.user_id and m.school_id = s.school_id and m.role = 'parent' and m.is_active
    where sg.student_id = p_student and g.user_id = auth.uid());
$$;
create or replace function public.is_self_student(p_student uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.students s
    join public.profiles p on p.id = s.user_id and p.is_active
    join public.school_memberships m on m.user_id = s.user_id and m.school_id = s.school_id and m.role = 'student' and m.is_active
    where s.id = p_student and s.user_id = auth.uid());
$$;
create or replace function public.is_teacher_of_class(p_school uuid, p_class uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.staff s
    join public.teacher_assignments ta on ta.staff_id = s.id and ta.school_id = s.school_id
    join public.profiles p on p.id = s.user_id and p.is_active
    join public.school_memberships m on m.user_id = s.user_id and m.school_id = s.school_id and m.role = 'teacher' and m.is_active
    where s.user_id = auth.uid() and s.school_id = p_school and ta.class_id = p_class and s.status = 'active');
$$;
create or replace function public.is_teacher_for(p_school uuid, p_class uuid, p_subject uuid, p_session uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.staff s
    join public.teacher_assignments ta on ta.staff_id = s.id and ta.school_id = s.school_id
    join public.profiles p on p.id = s.user_id and p.is_active
    join public.school_memberships m on m.user_id = s.user_id and m.school_id = s.school_id and m.role = 'teacher' and m.is_active
    where s.user_id = auth.uid() and s.school_id = p_school and s.status = 'active'
      and ta.class_id = p_class and ta.subject_id = p_subject and ta.session_id = p_session);
$$;
create or replace function public.is_form_teacher(p_school uuid, p_class uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.classes c
    join public.staff s on s.id = c.form_teacher_id and s.school_id = c.school_id
    join public.profiles p on p.id = s.user_id and p.is_active
    join public.school_memberships m on m.user_id = s.user_id and m.school_id = s.school_id and m.role = 'teacher' and m.is_active
    where c.id = p_class and c.school_id = p_school and s.user_id = auth.uid() and s.status = 'active');
$$;

-- ============ 5. Protect the owner and the school's identity ============
create or replace function public.guard_school_update()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is not null and not public.is_super_admin()
     and (new.slug is distinct from old.slug or new.status is distinct from old.status) then
    raise exception 'Only a super administrator can change the school code or status';
  end if;
  return new;
end $$;
revoke all on function public.guard_school_update() from public, anon, authenticated;
drop trigger if exists trg_guard_school_update on public.schools;
create trigger trg_guard_school_update before update on public.schools for each row execute function public.guard_school_update();

drop policy if exists memberships_update on public.school_memberships;
create policy memberships_update on public.school_memberships for update to authenticated
  using (public.is_super_admin() or (public.is_school_manager(school_id) and role <> 'proprietor'))
  with check (public.is_super_admin() or (public.is_school_manager(school_id) and role <> 'proprietor'));

create or replace function public.guard_membership_update()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is not null and (new.user_id <> old.user_id or new.school_id <> old.school_id) then
    raise exception 'A membership cannot be moved to another person or school';
  end if;
  return new;
end $$;
revoke all on function public.guard_membership_update() from public, anon, authenticated;
drop trigger if exists trg_guard_membership_update on public.school_memberships;
create trigger trg_guard_membership_update before update on public.school_memberships for each row execute function public.guard_membership_update();

-- names are limited in length
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, email, full_name)
  values (new.id, new.email, left(trim(coalesce(new.raw_user_meta_data ->> 'full_name', '')), 100))
  on conflict (id) do nothing;
  return new;
end $$;
revoke all on function public.handle_new_user() from public, anon, authenticated;
do $$ begin
  alter table public.profiles add constraint profiles_name_len check (char_length(coalesce(full_name, '')) <= 120) not valid;
exception when duplicate_object then null; end $$;

-- ============ 6. Publishing results: the term must belong to the school ============
create or replace function public.set_report_status(p_class uuid, p_term uuid, p_status text)
returns int language plpgsql security definer set search_path = public as $$
declare sch uuid; n int; tm public.terms; r record; nm text;
begin
  if p_status not in ('draft','published') then raise exception 'Invalid status'; end if;
  select c.school_id into sch from public.classes c where c.id = p_class;
  if sch is null then raise exception 'Class not found'; end if;
  if not (public.is_super_admin() or public.is_school_manager(sch)) then raise exception 'Not allowed'; end if;
  select * into tm from public.terms where id = p_term;
  if tm.id is null or tm.school_id <> sch then raise exception 'Term not found'; end if;
  if p_status = 'published' then
    for r in select distinct s.student_id from public.scores s
             where s.class_id = p_class and s.term_id = p_term and not public.report_published(s.student_id, p_term) loop
      select first_name || ' ' || last_name into nm from public.students where id = r.student_id;
      perform public.notify_guardians(r.student_id, 'report', 'Report card published', 'The ' || tm.name || ' report card for ' || nm || ' is now available.', 'myreports', true);
    end loop;
  end if;
  insert into public.report_cards(school_id, student_id, class_id, session_id, term_id, status, published_at)
  select distinct s.school_id, s.student_id, p_class, s.session_id, p_term, p_status, case when p_status = 'published' then now() end
  from public.scores s where s.class_id = p_class and s.term_id = p_term
  on conflict (student_id, term_id) do update set
    status = excluded.status, published_at = excluded.published_at, class_id = excluded.class_id, updated_at = now();
  get diagnostics n = row_count;
  return n;
end $$;
revoke all on function public.set_report_status(uuid, uuid, text) from public, anon;
grant execute on function public.set_report_status(uuid, uuid, text) to authenticated;

-- ============ 7. Public admission form: consent, rate limits ============
alter table public.admission_applications add column if not exists consent_at timestamptz;

drop function if exists public.submit_application(text,text,text,text,date,text,text,text,text,text);
create or replace function public.submit_application(
  p_slug text, p_first text, p_last text, p_gender text, p_dob date, p_class text,
  p_guardian text, p_phone text, p_email text, p_notes text, p_consent boolean default false)
returns text language plpgsql security definer set search_path = public as $$
declare sid uuid; ref text;
begin
  select id into sid from public.schools where slug = lower(trim(p_slug)) and status = 'active';
  if sid is null then raise exception 'This school is not accepting applications.'; end if;
  perform public.throttle('sub:' || sid::text, 60, 3600);
  if not coalesce(p_consent, false) then raise exception 'Please tick the box to confirm you agree to the privacy notice.'; end if;
  if length(trim(coalesce(p_first,''))) < 1 or length(trim(coalesce(p_last,''))) < 1
     or length(trim(coalesce(p_guardian,''))) < 2 or length(trim(coalesce(p_phone,''))) < 7 then
    raise exception 'Please fill in all required fields.';
  end if;
  if length(p_first) > 80 or length(p_last) > 80 or length(p_guardian) > 120 or length(coalesce(p_notes,'')) > 1000
     or length(coalesce(p_class,'')) > 40 or length(coalesce(p_email,'')) > 120 or length(p_phone) > 20 then
    raise exception 'One of the fields is too long.';
  end if;
  if p_dob is not null and (p_dob > current_date or p_dob < current_date - interval '30 years') then
    raise exception 'Check the date of birth.';
  end if;
  if (select count(*) from public.admission_applications
      where school_id = sid and guardian_phone = trim(p_phone) and created_at > now() - interval '1 hour') >= 5 then
    raise exception 'Too many applications from this phone number. Try again later.';
  end if;
  ref := 'APP-' || to_char(current_date,'YYYY') || '-' || lpad(public.next_number(sid,'application')::text, 5, '0');
  insert into public.admission_applications(school_id, reference_no, first_name, last_name, gender, date_of_birth,
    class_applied, guardian_name, guardian_phone, guardian_email, notes, consent_at)
  values (sid, ref, trim(p_first), trim(p_last), nullif(p_gender,''), p_dob, nullif(trim(coalesce(p_class,'')),''),
          trim(p_guardian), trim(p_phone), nullif(trim(coalesce(p_email,'')),''), nullif(trim(coalesce(p_notes,'')),''), now());
  return ref;
end $$;

create or replace function public.check_application(p_ref text, p_phone text)
returns text language plpgsql volatile security definer set search_path = public as $$
declare s text;
begin
  perform public.throttle('chk:' || upper(trim(coalesce(p_ref, ''))), 8, 3600);
  perform public.throttle('chk:all', 500, 3600);
  select status into s from public.admission_applications
    where reference_no = upper(trim(p_ref)) and guardian_phone = trim(p_phone) limit 1;
  return s;
end $$;

revoke all on function public.submit_application(text,text,text,text,date,text,text,text,text,text,boolean) from public;
grant execute on function public.submit_application(text,text,text,text,date,text,text,text,text,text,boolean) to anon, authenticated;
revoke all on function public.check_application(text, text) from public;
grant execute on function public.check_application(text, text) to anon, authenticated;

-- ============ 8. Right to erasure: remove a student's personal data (proprietor or super admin only) ============
-- Financial records (invoices and receipts) are kept for the school's accounting duties but no longer show a name.
-- Returns the storage file paths to delete by hand in Supabase > Storage.
create or replace function public.anonymize_student(p_student uuid)
returns text language plpgsql security definer set search_path = public as $$
declare stu public.students; paths text[];
begin
  select * into stu from public.students where id = p_student;
  if stu.id is null then raise exception 'Student not found'; end if;
  if not (public.is_super_admin() or public.has_school_role(stu.school_id, array['proprietor']::public.app_role[])) then
    raise exception 'Only the proprietor or a super administrator can erase a student record';
  end if;
  select array_remove(array[stu.photo_path], null) into paths;
  update public.students set first_name = 'Removed', last_name = 'Student', other_names = null, gender = null, date_of_birth = null,
    address = null, emergency_name = null, emergency_phone = null, photo_path = null, user_id = null,
    status = 'withdrawn', deleted_at = coalesce(deleted_at, now()) where id = p_student;
  delete from public.student_sensitive where student_id = p_student;
  delete from public.guardians g where g.id in (select guardian_id from public.student_guardians where student_id = p_student)
    and not exists (select 1 from public.student_guardians sg where sg.guardian_id = g.id and sg.student_id <> p_student);
  delete from public.student_guardians where student_id = p_student;
  with d as (delete from public.submissions where student_id = p_student returning file_path)
    select paths || coalesce(array_agg(file_path) filter (where file_path is not null), '{}') into paths from d;
  update public.admission_applications set first_name = 'Removed', last_name = 'Applicant', gender = null, date_of_birth = null,
    guardian_name = 'Removed', guardian_phone = '0000000', guardian_email = null, notes = null where student_id = p_student;
  delete from public.notifications where body ilike '%' || coalesce(nullif(stu.first_name, ''), '~~none~~') || ' ' || coalesce(nullif(stu.last_name, ''), '~~none~~') || '%' and school_id = stu.school_id;
  update public.audit_logs set old_data = null, new_data = null
    where school_id = stu.school_id and (record_id = p_student::text or old_data ->> 'student_id' = p_student::text or new_data ->> 'student_id' = p_student::text);
  return array_to_string(paths, E'\n');
end $$;
revoke all on function public.anonymize_student(uuid) from public, anon;
grant execute on function public.anonymize_student(uuid) to authenticated;

-- ============ 9. Final privilege pass ============
-- Signed-in users may call the app's functions; internal helpers stay private.
grant execute on all functions in schema public to authenticated;
revoke execute on function public.next_number(uuid, text) from authenticated;
revoke execute on function public.notify_guardians(uuid, text, text, text, text, boolean) from authenticated;
revoke execute on function public.notify_class(uuid, text, text, text, text) from authenticated;
revoke execute on function public._class_rank(uuid, uuid) from authenticated;
revoke execute on function public.throttle(text, int, int) from authenticated;
-- Anonymous visitors: only the public admission form and status check
revoke all on all functions in schema public from anon;
grant execute on function public.submit_application(text,text,text,text,date,text,text,text,text,text,boolean) to anon;
grant execute on function public.check_application(text, text) to anon;
