# Security review: Excellentia Smart School

**Who did this review:** the developer (Claude), by reading every table, policy, function and screen built so far. This is a careful self-review, **not** an independent penetration test. Before the system holds large volumes of children's data, have a qualified security professional test it.

## Fixed in migration 013 (run it after 001 to 012)

| # | Severity | Problem found | Fix |
|---|---|---|---|
| 1 | High | A school administrator could link a guardian, enrolment or class record to another school's student if they knew its ID (cross-school access) | A database check now rejects any linked record from a different school |
| 2 | High | Deactivating a parent, student or teacher in **Members** did not stop them reading records | Access now requires an active membership and active account |
| 3 | Medium | Internal database functions could be called by anyone on the internet, not just signed-in users | Only the public admission form and status check are open to visitors |
| 4 | Medium | Application status could be guessed repeatedly; admission form had no school-wide limit | Rate limits on both |
| 5 | Medium | A school administrator could demote the proprietor, change the school's code or status, or move memberships to other people or schools | Blocked; only a super administrator can change code/status |
| 6 | Low | Publishing results did not check the term belonged to the school; names had no length limit | Checked and limited |
| 7 | NDPA | No consent on the admission form, no privacy notice, no way to erase a student | Consent tick box (saved with a timestamp), `privacy.html` template, and `anonymize_student()` |

## Hardening in the app files
- Content Security Policy in `index.html`: only the app's own scripts and the Supabase library may run.
- Clickjacking guard (the app refuses to run inside another site's frame).
- `no-referrer` policy; removed the one inline script handler.
- All user text is escaped before display; CSV exports neutralise spreadsheet formulas; uploads accept listed file types only; logo accepts images only (no SVG).

## What is still open (honest list)
1. **Passwords and 2FA.** The app has no two-factor sign-in yet. Admin accounts are the biggest risk. Use long unique passwords and turn on 2FA for the Gmail, Supabase and GitHub accounts you use.
2. **No CAPTCHA** on the public admission form (rate limits only).
3. **Free Supabase plan:** no automatic backups, and projects pause after about a week of inactivity (you have seen this on your other projects). Use the Pro plan before real use.
4. **Supabase library is loaded from a CDN** without an integrity hash. It is pinned to one version. Consider hosting your own copy.
5. **Email, SMS and WhatsApp are not built**, so nothing leaves the system by those routes.
6. Teachers can see date of birth, address and emergency contact for students in their classes.
7. Notifications contain names (they are removed by `anonymize_student`).
8. Backups, retention periods and legal registration duties under the Nigeria Data Protection Act depend on how the school operates. Ask a data-protection professional or the Nigeria Data Protection Commission what applies to you. This document is not legal advice.

## Your actions in Supabase (do these before real use)
- **Authentication → Sign In / Providers → Email:** Confirm email ON; minimum password length 8 or more.
- **Authentication → SMTP:** set your own email provider (the free default is limited).
- **Authentication → URL Configuration:** Site URL and Redirect URLs set to your site only.
- **Project Settings → API:** the `service_role` / secret key must never appear in any file or chat.
- **Backups:** upgrade to Pro for daily backups, or export the database regularly. Practise one restore.
- **Team:** keep the Supabase and GitHub accounts to people you trust, with 2FA on.

## Erasing a student's data (right to erasure)
Only the proprietor or a super administrator can do this. It cannot be undone.
1. Supabase → SQL Editor, replace the id with the student's id (open the student in the app and copy it from Table Editor → students):
   `select public.anonymize_student('STUDENT-ID-HERE');`
2. The result lists file paths (photo and submitted work). Delete them in **Storage** (buckets `student-photos` and `learning-files`).
3. Invoices and receipts are kept for accounting but no longer show the child's name.

## If you suspect a breach
1. Change your super-admin and Supabase passwords; sign out all sessions (Authentication → Users).
2. Check **Audit log** in the app and Supabase **Logs** for what happened.
3. Rotate keys if any secret was exposed. Tell the school proprietor. Seek advice on whether the Nigeria Data Protection Commission and affected families must be told, and within what time.

## Security tests to run (add to the checklist)
- Deactivate a parent in **Members**, then check they lose access immediately.
- Create a second school and confirm its administrator sees none of the first school's data.
- As a school administrator, try to change the school code: it should be refused.
- Open the site and the browser console: no red "Content Security Policy" errors when using every page.
