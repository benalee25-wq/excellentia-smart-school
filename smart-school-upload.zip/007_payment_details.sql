-- Migration 007: school payment details (shown on invoices and to parents). Run AFTER 001-006.
alter table public.schools add column if not exists bank_name text;
alter table public.schools add column if not exists account_name text;
alter table public.schools add column if not exists account_number text;
alter table public.schools add column if not exists payment_note text;
alter table public.schools add column if not exists accepted_methods text[] not null default array['cash','bank_transfer','pos'];

do $$ begin
  alter table public.schools add constraint schools_account_number_check check (account_number is null or account_number ~ '^[0-9]{10}$');
exception when duplicate_object then null; end $$;
do $$ begin
  alter table public.schools add constraint schools_accepted_methods_check check (accepted_methods <@ array['cash','bank_transfer','pos','other']);
exception when duplicate_object then null; end $$;
