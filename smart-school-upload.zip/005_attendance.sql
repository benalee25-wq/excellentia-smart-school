-- Migration 005: daily student attendance. Run AFTER 001-004.

create table if not exists public.attendance (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null references public.schools(id) on delete cascade,
  student_id uuid not null references public.students(id) on delete cascade,
  class_id uuid not null references public.classes(id) on delete cascade,
  session_id uuid not null references public.academic_sessions(id) on delete cascade,
  term_id uuid not null references public.terms(id) on delete cascade,
  att_date date not null,
  status text not null check (status in ('present','absent','late','excused')),
  note text,
  marked_by uuid,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (student_id, att_date)
);
create index if not exists idx_att_class_date on public.attendance(class_id, att_date);
create index if not exists idx_att_student_date on public.attendance(student_id, att_date);

create or replace function public.lagos_today()
returns date language sql stable as $$ select (now() at time zone 'Africa/Lagos')::date $$;

-- Fills term/session from the date; blocks bad dates and late edits by non-admins
create or replace function public.validate_attendance()
returns trigger language plpgsql security definer set search_path = public as $$
declare t record; mgr boolean;
begin
  if not exists (select 1 from public.students where id = new.student_id and school_id = new.school_id) then raise exception 'Student is not in this school'; end if;
  if not exists (select 1 from public.classes where id = new.class_id and school_id = new.school_id) then raise exception 'Class is not in this school'; end if;
  select id, session_id into t from public.terms
    where school_id = new.school_id and new.att_date between start_date and end_date limit 1;
  if not found then raise exception 'No term covers % . Add the term under Sessions & terms first.', new.att_date; end if;
  new.term_id := t.id; new.session_id := t.session_id;
  if not exists (select 1 from public.students where id = new.student_id and current_class_id = new.class_id)
     and not exists (select 1 from public.enrollments where student_id = new.student_id and class_id = new.class_id and session_id = new.session_id) then
    raise exception 'Student is not in this class';
  end if;
  if new.att_date > public.lagos_today() then raise exception 'You cannot record attendance for a future date'; end if;
  mgr := public.is_super_admin() or public.is_school_manager(new.school_id);
  if not mgr and new.att_date < public.lagos_today() - 7 then
    raise exception 'Only an administrator can change attendance older than 7 days';
  end if;
  new.marked_by := auth.uid(); new.updated_at := now();
  return new;
end $$;
drop trigger if exists trg_validate_attendance on public.attendance;
create trigger trg_validate_attendance before insert or update on public.attendance
  for each row execute function public.validate_attendance();

-- audit only corrections and deletions (not every daily mark)
drop trigger if exists trg_audit_attendance on public.attendance;
create trigger trg_audit_attendance after update or delete on public.attendance
  for each row execute function public.log_audit();

alter table public.attendance enable row level security;
drop policy if exists att_select on public.attendance;
create policy att_select on public.attendance for select to authenticated using (
  public.is_super_admin() or public.is_school_manager(school_id)
  or public.is_form_teacher(school_id, class_id) or public.is_teacher_of_class(school_id, class_id)
  or public.is_guardian_of(student_id) or public.is_self_student(student_id));
drop policy if exists att_write on public.attendance;
create policy att_write on public.attendance for all to authenticated
  using (public.is_super_admin() or public.is_school_manager(school_id) or public.is_form_teacher(school_id, class_id))
  with check (public.is_super_admin() or public.is_school_manager(school_id) or public.is_form_teacher(school_id, class_id));

-- one student's term summary (used on report cards and the parent view)
create or replace function public.attendance_summary(p_student uuid, p_term uuid)
returns table(present int, late int, absent int, excused int, days_open int)
language plpgsql stable security definer set search_path = public as $$
declare cid uuid; sch uuid;
begin
  select a.class_id, a.school_id into cid, sch from public.attendance a
    where a.student_id = p_student and a.term_id = p_term order by a.att_date desc limit 1;
  if cid is null then return query select 0, 0, 0, 0, 0; return; end if;
  if not (public.is_super_admin() or public.is_school_manager(sch) or public.is_form_teacher(sch, cid)
          or public.is_teacher_of_class(sch, cid) or public.is_guardian_of(p_student) or public.is_self_student(p_student)) then
    raise exception 'Not allowed';
  end if;
  return query
    select (count(*) filter (where a.student_id = p_student and a.status = 'present'))::int,
           (count(*) filter (where a.student_id = p_student and a.status = 'late'))::int,
           (count(*) filter (where a.student_id = p_student and a.status = 'absent'))::int,
           (count(*) filter (where a.student_id = p_student and a.status = 'excused'))::int,
           (count(distinct a.att_date))::int
    from public.attendance a where a.class_id = cid and a.term_id = p_term;
end $$;
revoke all on function public.attendance_summary(uuid, uuid) from public, anon;
grant execute on function public.attendance_summary(uuid, uuid) to authenticated;

-- class report for a date range
create or replace function public.attendance_report(p_class uuid, p_from date, p_to date)
returns table(student_id uuid, present int, late int, absent int, excused int, days_open int)
language plpgsql stable security definer set search_path = public as $$
declare sch uuid; n int;
begin
  select c.school_id into sch from public.classes c where c.id = p_class;
  if sch is null then raise exception 'Class not found'; end if;
  if not (public.is_super_admin() or public.is_school_manager(sch) or public.is_form_teacher(sch, p_class) or public.is_teacher_of_class(sch, p_class)) then
    raise exception 'Not allowed';
  end if;
  select count(distinct a.att_date)::int into n from public.attendance a where a.class_id = p_class and a.att_date between p_from and p_to;
  return query
    select a.student_id,
           (count(*) filter (where a.status = 'present'))::int, (count(*) filter (where a.status = 'late'))::int,
           (count(*) filter (where a.status = 'absent'))::int, (count(*) filter (where a.status = 'excused'))::int, n
    from public.attendance a where a.class_id = p_class and a.att_date between p_from and p_to group by a.student_id;
end $$;
revoke all on function public.attendance_report(uuid, date, date) from public, anon;
grant execute on function public.attendance_report(uuid, date, date) to authenticated;

revoke all on all tables in schema public from anon;
