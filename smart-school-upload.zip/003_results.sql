-- Migration 003: scores (CA1 20 + CA2 20 + Exam 60), grading scale,
-- class ranking and report cards. Run AFTER 001 and 002.

create table if not exists public.grading_scales (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null references public.schools(id) on delete cascade,
  grade text not null check (char_length(grade) between 1 and 4),
  min_score numeric(5,2) not null,
  max_score numeric(5,2) not null,
  remark text,
  check (min_score >= 0 and max_score <= 100 and max_score >= min_score),
  unique (school_id, grade)
);

create table if not exists public.scores (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null references public.schools(id) on delete cascade,
  student_id uuid not null references public.students(id) on delete cascade,
  class_id uuid not null references public.classes(id) on delete cascade,
  subject_id uuid not null references public.subjects(id) on delete cascade,
  session_id uuid not null references public.academic_sessions(id) on delete cascade,
  term_id uuid not null references public.terms(id) on delete cascade,
  ca1 numeric(4,1) check (ca1 between 0 and 20),
  ca2 numeric(4,1) check (ca2 between 0 and 20),
  exam numeric(4,1) check (exam between 0 and 60),
  total numeric(5,1) generated always as (coalesce(ca1,0) + coalesce(ca2,0) + coalesce(exam,0)) stored,
  entered_by uuid,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (student_id, subject_id, term_id)
);
create index if not exists idx_scores_class_term on public.scores(class_id, term_id);
create index if not exists idx_scores_student_term on public.scores(student_id, term_id);

create table if not exists public.report_cards (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null references public.schools(id) on delete cascade,
  student_id uuid not null references public.students(id) on delete cascade,
  class_id uuid not null references public.classes(id) on delete cascade,
  session_id uuid not null references public.academic_sessions(id) on delete cascade,
  term_id uuid not null references public.terms(id) on delete cascade,
  teacher_comment text,
  principal_comment text,
  status text not null default 'draft' check (status in ('draft','published')),
  published_at timestamptz,
  updated_at timestamptz not null default now(),
  unique (student_id, term_id)
);

-- ---------- helpers ----------
create or replace function public.is_teacher_for(p_school uuid, p_class uuid, p_subject uuid, p_session uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.staff s join public.teacher_assignments ta on ta.staff_id = s.id
    where s.user_id = auth.uid() and s.school_id = p_school and s.status = 'active'
      and ta.class_id = p_class and ta.subject_id = p_subject and ta.session_id = p_session);
$$;
create or replace function public.report_published(p_student uuid, p_term uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.report_cards where student_id = p_student and term_id = p_term and status = 'published');
$$;

-- ---------- score validation ----------
create or replace function public.validate_score()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if not exists (select 1 from public.students where id = new.student_id and school_id = new.school_id) then raise exception 'Student is not in this school'; end if;
  if not exists (select 1 from public.classes where id = new.class_id and school_id = new.school_id) then raise exception 'Class is not in this school'; end if;
  if not exists (select 1 from public.subjects where id = new.subject_id and school_id = new.school_id) then raise exception 'Subject is not in this school'; end if;
  if not exists (select 1 from public.terms where id = new.term_id and school_id = new.school_id and session_id = new.session_id) then raise exception 'Term does not match the session'; end if;
  if not exists (select 1 from public.students where id = new.student_id and current_class_id = new.class_id)
     and not exists (select 1 from public.enrollments where student_id = new.student_id and class_id = new.class_id and session_id = new.session_id) then
    raise exception 'Student is not in this class';
  end if;
  new.entered_by := auth.uid(); new.updated_at := now();
  return new;
end $$;
drop trigger if exists trg_validate_score on public.scores;
create trigger trg_validate_score before insert or update on public.scores for each row execute function public.validate_score();

do $$ declare t text; begin
  foreach t in array array['grading_scales','scores','report_cards'] loop
    execute format('drop trigger if exists trg_audit_%1$s on public.%1$s', t);
    execute format('create trigger trg_audit_%1$s after insert or update or delete on public.%1$s for each row execute function public.log_audit()', t);
  end loop;
end $$;

-- ---------- RLS ----------
alter table public.grading_scales enable row level security;
alter table public.scores enable row level security;
alter table public.report_cards enable row level security;

drop policy if exists gs_select on public.grading_scales;
create policy gs_select on public.grading_scales for select to authenticated
  using (public.is_super_admin() or public.is_school_member(school_id));
drop policy if exists gs_write on public.grading_scales;
create policy gs_write on public.grading_scales for all to authenticated
  using (public.is_super_admin() or public.is_school_manager(school_id))
  with check (public.is_super_admin() or public.is_school_manager(school_id));

drop policy if exists scores_select on public.scores;
create policy scores_select on public.scores for select to authenticated using (
  public.is_super_admin() or public.is_school_manager(school_id)
  or public.is_teacher_for(school_id, class_id, subject_id, session_id)
  or ((public.is_guardian_of(student_id) or public.is_self_student(student_id)) and public.report_published(student_id, term_id)));
drop policy if exists scores_write on public.scores;
create policy scores_write on public.scores for all to authenticated
  using (public.is_super_admin() or public.is_school_manager(school_id)
         or (public.is_teacher_for(school_id, class_id, subject_id, session_id) and not public.report_published(student_id, term_id)))
  with check (public.is_super_admin() or public.is_school_manager(school_id)
         or (public.is_teacher_for(school_id, class_id, subject_id, session_id) and not public.report_published(student_id, term_id)));

drop policy if exists rc_select on public.report_cards;
create policy rc_select on public.report_cards for select to authenticated using (
  public.is_super_admin() or public.is_school_manager(school_id) or public.is_teacher_of_class(school_id, class_id)
  or ((public.is_guardian_of(student_id) or public.is_self_student(student_id)) and status = 'published'));
-- no direct write policy: changes go through the functions below
revoke insert, update, delete on public.report_cards from authenticated;

-- ---------- ranking (internal) ----------
create or replace function public._class_rank(p_class uuid, p_term uuid)
returns table(student_id uuid, subjects int, total numeric, average numeric, rank_pos int)
language sql stable security definer set search_path = public as $$
  with t as (
    select sc.student_id as sid, count(*)::int as n, sum(sc.total) as tot, round(avg(sc.total), 2) as avg
    from public.scores sc where sc.class_id = p_class and sc.term_id = p_term group by sc.student_id)
  select sid, n, tot, avg, (rank() over (order by avg desc))::int from t;
$$;
revoke all on function public._class_rank(uuid, uuid) from public, anon, authenticated;

create or replace function public.class_results(p_class uuid, p_term uuid)
returns table(student_id uuid, subjects int, total numeric, average numeric, rank_pos int)
language plpgsql stable security definer set search_path = public as $$
declare sch uuid;
begin
  select c.school_id into sch from public.classes c where c.id = p_class;
  if sch is null then raise exception 'Class not found'; end if;
  if not (public.is_super_admin() or public.is_school_manager(sch) or public.is_teacher_of_class(sch, p_class)) then raise exception 'Not allowed'; end if;
  return query select * from public._class_rank(p_class, p_term) order by 5, 1;
end $$;
revoke all on function public.class_results(uuid, uuid) from public, anon;
grant execute on function public.class_results(uuid, uuid) to authenticated;

create or replace function public.student_standing(p_student uuid, p_term uuid)
returns table(rank_pos int, class_size int, average numeric, subjects int, total numeric)
language plpgsql stable security definer set search_path = public as $$
declare cid uuid; sch uuid;
begin
  select s.class_id, s.school_id into cid, sch from public.scores s where s.student_id = p_student and s.term_id = p_term limit 1;
  if cid is null then return; end if;
  if not (public.is_super_admin() or public.is_school_manager(sch) or public.is_teacher_of_class(sch, cid)
          or ((public.is_guardian_of(p_student) or public.is_self_student(p_student)) and public.report_published(p_student, p_term))) then
    raise exception 'Not allowed';
  end if;
  return query select r.rank_pos, (select count(*)::int from public._class_rank(cid, p_term)), r.average, r.subjects, r.total
               from public._class_rank(cid, p_term) r where r.student_id = p_student;
end $$;
revoke all on function public.student_standing(uuid, uuid) from public, anon;
grant execute on function public.student_standing(uuid, uuid) to authenticated;

-- ---------- comments, publishing, default scale ----------
create or replace function public.save_comment(p_student uuid, p_term uuid, p_teacher text, p_principal text default null)
returns void language plpgsql security definer set search_path = public as $$
declare stu public.students; tm public.terms; mgr boolean;
begin
  select * into stu from public.students where id = p_student;
  select * into tm from public.terms where id = p_term;
  if stu.id is null or tm.id is null or stu.school_id <> tm.school_id then raise exception 'Not found'; end if;
  if stu.current_class_id is null then raise exception 'Student has no class'; end if;
  mgr := public.is_super_admin() or public.is_school_manager(stu.school_id);
  if not (mgr or public.is_teacher_of_class(stu.school_id, stu.current_class_id)) then raise exception 'Not allowed'; end if;
  if not mgr and public.report_published(p_student, p_term) then raise exception 'This report has been published'; end if;
  insert into public.report_cards(school_id, student_id, class_id, session_id, term_id, teacher_comment, principal_comment)
  values (stu.school_id, p_student, stu.current_class_id, tm.session_id, p_term,
          nullif(trim(coalesce(p_teacher,'')),''), case when mgr then nullif(trim(coalesce(p_principal,'')),'') end)
  on conflict (student_id, term_id) do update set
    teacher_comment = excluded.teacher_comment,
    principal_comment = case when mgr then excluded.principal_comment else public.report_cards.principal_comment end,
    updated_at = now();
end $$;
revoke all on function public.save_comment(uuid, uuid, text, text) from public, anon;
grant execute on function public.save_comment(uuid, uuid, text, text) to authenticated;

create or replace function public.set_report_status(p_class uuid, p_term uuid, p_status text)
returns int language plpgsql security definer set search_path = public as $$
declare sch uuid; n int;
begin
  if p_status not in ('draft','published') then raise exception 'Invalid status'; end if;
  select c.school_id into sch from public.classes c where c.id = p_class;
  if sch is null then raise exception 'Class not found'; end if;
  if not (public.is_super_admin() or public.is_school_manager(sch)) then raise exception 'Not allowed'; end if;
  insert into public.report_cards(school_id, student_id, class_id, session_id, term_id, status, published_at)
  select distinct s.school_id, s.student_id, p_class, s.session_id, p_term, p_status,
         case when p_status = 'published' then now() end
  from public.scores s where s.class_id = p_class and s.term_id = p_term
  on conflict (student_id, term_id) do update set
    status = excluded.status, published_at = excluded.published_at, class_id = excluded.class_id, updated_at = now();
  get diagnostics n = row_count;
  return n;
end $$;
revoke all on function public.set_report_status(uuid, uuid, text) from public, anon;
grant execute on function public.set_report_status(uuid, uuid, text) to authenticated;

create or replace function public.ensure_grading_scale(p_school uuid)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not (public.is_super_admin() or public.is_school_manager(p_school)) then raise exception 'Not allowed'; end if;
  if exists (select 1 from public.grading_scales where school_id = p_school) then return; end if;
  insert into public.grading_scales(school_id, grade, min_score, max_score, remark) values
    (p_school,'A',70,100,'Excellent'), (p_school,'B',60,69,'Very good'), (p_school,'C',50,59,'Good'),
    (p_school,'D',45,49,'Fair'), (p_school,'E',40,44,'Pass'), (p_school,'F',0,39,'Fail');
end $$;
revoke all on function public.ensure_grading_scale(uuid) from public, anon;
grant execute on function public.ensure_grading_scale(uuid) to authenticated;

revoke all on all tables in schema public from anon;
