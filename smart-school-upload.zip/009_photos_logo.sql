-- Migration 009: school logo (public bucket) and student photos (PRIVATE bucket, signed links).
-- Run AFTER 001-008.

alter table public.students add column if not exists photo_path text;

create or replace function public.safe_uuid(p text)
returns uuid language plpgsql immutable as $$
begin return p::uuid; exception when others then return null; end $$;

-- who may open a student's photo: managers, bursar, the student, linked parents, teachers of the student's class
create or replace function public.student_file_visible(p_name text)
returns boolean language plpgsql stable security definer set search_path = public as $$
declare sch uuid; stu uuid; cls uuid;
begin
  sch := public.safe_uuid(split_part(p_name, '/', 1));
  stu := public.safe_uuid(split_part(split_part(p_name, '/', 2), '.', 1));
  if sch is null or stu is null then return false; end if;
  if public.is_super_admin() or public.is_school_manager(sch) then return true; end if;
  if not exists (select 1 from public.students where id = stu and school_id = sch) then return false; end if;
  if public.has_school_role(sch, array['bursar']::public.app_role[]) then return true; end if;
  if public.is_guardian_of(stu) or public.is_self_student(stu) then return true; end if;
  select current_class_id into cls from public.students where id = stu;
  return cls is not null and public.is_teacher_of_class(sch, cls);
end $$;

create or replace function public.can_manage_school_file(p_name text)
returns boolean language plpgsql stable security definer set search_path = public as $$
declare sch uuid;
begin
  sch := public.safe_uuid(split_part(p_name, '/', 1));
  return sch is not null and (public.is_super_admin() or public.is_school_manager(sch));
end $$;

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types) values
  ('school-logos', 'school-logos', true, 1048576, array['image/png','image/jpeg','image/webp']),
  ('student-photos', 'student-photos', false, 524288, array['image/jpeg'])
on conflict (id) do update set public = excluded.public, file_size_limit = excluded.file_size_limit, allowed_mime_types = excluded.allowed_mime_types;

drop policy if exists "ssms_logos_read" on storage.objects;
create policy "ssms_logos_read" on storage.objects for select to authenticated using (bucket_id = 'school-logos');
drop policy if exists "ssms_logos_insert" on storage.objects;
create policy "ssms_logos_insert" on storage.objects for insert to authenticated with check (bucket_id = 'school-logos' and public.can_manage_school_file(name));
drop policy if exists "ssms_logos_update" on storage.objects;
create policy "ssms_logos_update" on storage.objects for update to authenticated using (bucket_id = 'school-logos' and public.can_manage_school_file(name)) with check (bucket_id = 'school-logos' and public.can_manage_school_file(name));
drop policy if exists "ssms_logos_delete" on storage.objects;
create policy "ssms_logos_delete" on storage.objects for delete to authenticated using (bucket_id = 'school-logos' and public.can_manage_school_file(name));

drop policy if exists "ssms_photos_read" on storage.objects;
create policy "ssms_photos_read" on storage.objects for select to authenticated using (bucket_id = 'student-photos' and public.student_file_visible(name));
drop policy if exists "ssms_photos_insert" on storage.objects;
create policy "ssms_photos_insert" on storage.objects for insert to authenticated with check (bucket_id = 'student-photos' and public.can_manage_school_file(name));
drop policy if exists "ssms_photos_update" on storage.objects;
create policy "ssms_photos_update" on storage.objects for update to authenticated using (bucket_id = 'student-photos' and public.can_manage_school_file(name)) with check (bucket_id = 'student-photos' and public.can_manage_school_file(name));
drop policy if exists "ssms_photos_delete" on storage.objects;
create policy "ssms_photos_delete" on storage.objects for delete to authenticated using (bucket_id = 'student-photos' and public.can_manage_school_file(name));
