# Excellentia Smart School: test checklist (before real students are added)

Run the SQL files in order: 001 to 012. Upload every file. Then work through this list.
Use 4 accounts: Super admin (you), School admin, Teacher, Parent (add a Student account if you can).

## A. Install check (super admin)
- [ ] Site loads styled, sign-in works
- [ ] Menu shows: Dashboard, Sessions & terms, Classes, Members, Audit log, Students, Staff, Subjects & teaching, Admissions, Score entry, Results, Grading scale, Form teachers, School profile, Take attendance, Attendance report, Fee structure, Invoices & payments, Fees report, Announcements, Notifications, Timetable, Periods & rooms, Materials, Assignments
- [ ] Dashboard sections all load (no red "Run 010" messages)

## B. School admin
- [ ] Sees the school menu but NOT "Schools"
- [ ] School profile saves (name, motto, address, bank details, logo)

## C. Teacher
- [ ] Linked under Staff > Link login (role teacher), assigned class + subject, set as form teacher
- [ ] Sees ONLY own classes in Score entry and Materials
- [ ] Cannot see Fees, Members, Staff, Admissions
- [ ] Enters scores, takes attendance, writes class teacher comment (form teacher only)
- [ ] Creates a material and an assignment; marks a submission

## D. Parent (linked to Joshua via Students > Parents and guardians > Link login)
- [ ] Sees only: Fees, Attendance, Report cards, Timetable, Learning materials, Assignments, Announcements, Notifications
- [ ] Sees ONLY Joshua's data
- [ ] Report card visible only AFTER the admin publishes results
- [ ] Gets in-app alerts: absence, payment, invoice, report published, assignment, announcement

## E. Money
- [ ] Invoice generated for a class; part payment recorded; receipt prints; balance correct
- [ ] Same transfer reference cannot be entered twice
- [ ] Payment larger than balance is refused
- [ ] Only admin can discount or void (bursar and teacher cannot)

## F. Isolation (most important)
- [ ] Create a second school. Its admin cannot see the first school's students, fees or files
- [ ] A parent cannot open another child's invoice or report card

## G. Before going live
- [ ] Delete test students, invoices and accounts
- [ ] Supabase: Confirm email ON, custom SMTP set, backups plan
- [ ] Share the site address and application link

## H. Security (after running 013)
- [ ] Deactivate a parent in Members: they lose access to the child's data straight away
- [ ] A school administrator cannot change the school code or status (refused)
- [ ] A school administrator cannot demote the proprietor in Members
- [ ] Admission form requires the consent box; the application shows in Admissions
- [ ] No red "Content Security Policy" errors in the browser console on any page
- [ ] Admission status check locks out after repeated wrong guesses
