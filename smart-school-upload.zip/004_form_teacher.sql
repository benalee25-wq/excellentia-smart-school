-- Migration 004: form teachers, school motto. Run AFTER 001, 002, 003.

alter table public.classes add column if not exists form_teacher_id uuid references public.staff(id) on delete set null;
alter table public.schools add column if not exists motto text;

create or replace function public.validate_form_teacher()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.form_teacher_id is not null and not exists (
    select 1 from public.staff where id = new.form_teacher_id and school_id = new.school_id) then
    raise exception 'The form teacher must be a staff member of this school';
  end if;
  return new;
end $$;
drop trigger if exists trg_validate_form_teacher on public.classes;
create trigger trg_validate_form_teacher before insert or update of form_teacher_id on public.classes
  for each row execute function public.validate_form_teacher();

create or replace function public.is_form_teacher(p_school uuid, p_class uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.classes c join public.staff s on s.id = c.form_teacher_id
    where c.id = p_class and c.school_id = p_school and s.user_id = auth.uid() and s.status = 'active');
$$;

-- name of a class's form teacher, readable by anyone in the school (for report cards)
create or replace function public.class_form_teacher(p_class uuid)
returns text language plpgsql stable security definer set search_path = public as $$
declare sch uuid; nm text;
begin
  select c.school_id into sch from public.classes c where c.id = p_class;
  if sch is null or not (public.is_super_admin() or public.is_school_member(sch)) then return null; end if;
  select s.full_name into nm from public.classes c join public.staff s on s.id = c.form_teacher_id where c.id = p_class;
  return nm;
end $$;
revoke all on function public.class_form_teacher(uuid) from public, anon;
grant execute on function public.class_form_teacher(uuid) to authenticated;

-- comments: managers write both; only the class's form teacher writes the class teacher's comment
create or replace function public.save_comment(p_student uuid, p_term uuid, p_teacher text, p_principal text default null)
returns void language plpgsql security definer set search_path = public as $$
declare stu public.students; tm public.terms; mgr boolean;
begin
  select * into stu from public.students where id = p_student;
  select * into tm from public.terms where id = p_term;
  if stu.id is null or tm.id is null or stu.school_id <> tm.school_id then raise exception 'Not found'; end if;
  if stu.current_class_id is null then raise exception 'Student has no class'; end if;
  mgr := public.is_super_admin() or public.is_school_manager(stu.school_id);
  if not mgr then
    if not public.is_form_teacher(stu.school_id, stu.current_class_id) then
      raise exception 'Only the form teacher of this class can write the class teacher''s comment';
    end if;
    if public.report_published(p_student, p_term) then raise exception 'This report has been published'; end if;
  end if;
  insert into public.report_cards(school_id, student_id, class_id, session_id, term_id, teacher_comment, principal_comment)
  values (stu.school_id, p_student, stu.current_class_id, tm.session_id, p_term,
          nullif(trim(coalesce(p_teacher,'')),''), case when mgr then nullif(trim(coalesce(p_principal,'')),'') end)
  on conflict (student_id, term_id) do update set
    teacher_comment = excluded.teacher_comment,
    principal_comment = case when mgr then excluded.principal_comment else public.report_cards.principal_comment end,
    updated_at = now();
end $$;
revoke all on function public.save_comment(uuid, uuid, text, text) from public, anon;
grant execute on function public.save_comment(uuid, uuid, text, text) to authenticated;

revoke all on all tables in schema public from anon;
